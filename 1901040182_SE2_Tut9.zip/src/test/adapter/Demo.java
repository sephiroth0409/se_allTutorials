package test.adapter;

import test.adapter.adapter.SquarePegAdapter;
import test.adapter.round.RoundHole;
import test.adapter.round.RoundPeg;
import test.adapter.square.SquarePeg;

/**
 * Somewhere in client code...
 */
public class Demo {
	public static void main(String[] args) {
		//TO-DO: Create 2 instances of RoundHole and RoundPeg with same radius
	 	RoundHole hole = new RoundHole(5);
		 RoundPeg peg = new RoundPeg(5);
		//TO-DO: If RoundHole instance can "fits" with RoundPeg instance => show a message
	 	if (hole.fits(peg)){
			System.out.println("it fits perfectly");
		}
		//TO-DO: Create 2 instances of SquarePeg with 2 different widths
 		SquarePeg speg1= new SquarePeg(20);
		 SquarePeg speg2= new SquarePeg(21);
		//Note: You can't make RoundHole instance "fit" with SquarePeg instance
		//Therefore, we need to use Adapter for solving the problem.
		
		//TO-DO: Create 2 corresponding instances of SquarePegAdapter  
		 SquarePegAdapter speg_adapter_1 = new SquarePegAdapter(20);
		 SquarePegAdapter speg_adapter_2 = new SquarePegAdapter(21);
		//TO-DO: If the RoundHole instance can "fits" with "small" RoundPegAdapter instance 
		//show a suitable message
		if(speg_adapter_1.getRadius() ==speg_adapter_2.getRadius()){
			System.out.println("fits");
		}
		//TO-DO: If the RoundHole instance can not "fits" with "big" RoundPegAdapter instance
		if (hole.fits(speg_adapter_2)){
			System.out.println("hole fit round");
		}
		//show a suitable message
	}
}