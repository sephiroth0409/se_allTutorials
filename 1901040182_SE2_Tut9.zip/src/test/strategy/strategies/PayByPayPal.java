package test.strategy.strategies;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Concrete strategy. Implements PayPal payment method.
 */
public class PayByPayPal implements PayStrategy {
    private static final Map<String, String> DATA_BASE = new HashMap<>();
    private final BufferedReader READER = new BufferedReader(new InputStreamReader(System.in));
    private String email;
    private  String password;
    private boolean signedIn;
    public static final Pattern VALID_EMAIL_ADDRESS_REGEX =
            Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
                    Pattern.CASE_INSENSITIVE);

    static {
    	//TO-DO: 'put' some test data (password & email) to DATA_BASE
        DATA_BASE.put("password", "tuthoeng123");
        DATA_BASE.put("email","minhtan04092001@gmail.com");
    }

    //TO-DO: Implement the collectPaymentDetails() method
    /**
     * Collect customer's data.
     */
    @Override
    public void collectPaymentDetails() {
       //TO-DO: Add 'try-catch' block to catch the IO error
        try{

            //TO-DO: Ask for email & password then save them to suitable variables

            System.out.println("enter email: ");this.email = READER.readLine();
            Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(email);
            System.out.println("enter password: "); this.password = READER.readLine();
            //TO-DO: Verify the input values then display suitable message
            if(verify()){
                System.out.println("verification success");
            }
            else System.out.println("false pass");

        }catch (IOException e){
            System.out.println("input error");
        }


    }

    private boolean verify() {
        if(DATA_BASE.get("email").equals(email) &&
                DATA_BASE.get("password").equals(password)){
            signedIn = true;
        }
        return signedIn;
    }

    //TO-DO: Implement the pay() method
    /**
     * Save customer data for future shopping attempts.
     */
    @Override
    public boolean pay(int paymentAmount) {
    	/*if customer already 'signedIn' => display a message 
    	to show that customer is paying with PayPal with money amount
    	then return true else return false */
        if(signedIn){
            System.out.println("you're paying wwith paypal");
            return true;
        }
    	else return false;
    }

    private void setSignedIn(boolean signedIn) {
        this.signedIn = signedIn;
    }
}