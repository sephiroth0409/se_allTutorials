package test.bridge.remotes;

import test.bridge.devices.Device;

public class AdvancedRemote extends BasicRemote {

    public AdvancedRemote(Device device) {
        super.device = device;
    }

    //TO-DO: Implement the mute() method
    public void mute() {
    	//Display the current volume status is 'mute'
        System.out.println("muting");
        //Set the volume to 0
        super.device.setVolume(0);
    }
}
