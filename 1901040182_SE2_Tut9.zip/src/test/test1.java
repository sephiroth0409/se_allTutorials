package test;

public class test1 {
    public static void main (String [] args){
        System.out.println("abc");
    }
}
