package com.example.tut4springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tut4springbootApplication {

    public static void main(String[] args) {
        SpringApplication.run(Tut4springbootApplication.class, args);
    }

}
