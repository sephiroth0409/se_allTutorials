package com.example.tut4springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tut4springbootApplicationTests {

    @Test
    void contextLoads() {
    }

}
