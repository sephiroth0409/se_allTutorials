package com.example.demo.controller;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Optional;

@Controller
public class EmployeeController {
    @Autowired
    EmployeeRepository employeeRepository;
    @RequestMapping("/emp")
    public String viewEmployeeList (Model model){
        List<Employee> employeeList=employeeRepository.findAll();
        model.addAttribute("employees", employeeList);
        return "employeeList";
    }
    @RequestMapping("/emp/delete/{id}")
    public String DeleteEmployee(@PathVariable("id") long id){
        employeeRepository.deleteById(id);
        return "redirect:/emp";
    }

        @RequestMapping("/emp/edit/{id}")
        public String EditEmployee(@PathVariable("id") long id, Model model){
            Optional<Employee> employee = employeeRepository.findById(id);
            model.addAttribute("employees", employee);
            return "informationForm";
    }
        @RequestMapping("/emp/create/")
        public String CreateEmployee(Model model){
        model.addAttribute("employees", new Employee());
        return "informationForm";
        }
        @RequestMapping("/emp/save")
    public String saveEmployees(Employee employee ) {
        employeeRepository.save(employee);
        return "redirect:/emp";
    }
}
