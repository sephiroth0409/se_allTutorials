package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DemoController {
    @RequestMapping(value="/")
    public String demo(Model model){
        String fit = "Faculty of IT - Hanoi University";
        model.addAttribute("hanu", fit);
        return "demo";
    }
}
