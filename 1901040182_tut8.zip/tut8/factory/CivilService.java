package tutorial.tut7.todo.tut8.factory;

import java.util.Scanner;

// Create the CivilService class that extends Course abstract class
class CivilService extends Course {
	// TO-DO: Implement getDuration() method: set a specific duration and print value
	public void getDuration() {
		this.duration = 100;
		System.out.println(duration);
	}

	// TO-DO: Implement getFeePerSemester() method: set a specific fee and print value
	public void getFeePerSemester() {
		this.fee = 342;
		System.out.println(fee);
	}
}