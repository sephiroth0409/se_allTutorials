package tutorial.tut7.todo.tut8.factory;

import java.util.Scanner;

// Create the Computer class that extends Course abstract class
class Computer extends Course {
	// TO-DO: Implement getDuration() method: set a specific duration and print value
	public void getDuration() {
		this.duration = 400;
		System.out.println(duration);
	}

	// TO-DO: Implement getFeePerSemester() method: set a specific fee and print value
	public void getFeePerSemester() {

		this.fee = 500;
		System.out.println(fee);
	}
} 
