package tutorial.tut7.todo.tut8.factory;

import java.util.Scanner;

// Creating the Health class that extends Course abstract class
class Health extends Course {
	// TO-DO: Implement getDuration() method: set a specific duration and print value
	public void getDuration() {
		this.duration = 543;
		System.out.println(duration);
	}

	// TO-DO: Implement getFeePerSemester() method: set a specific fee and print value
	public void getFeePerSemester() {
		this.fee = 433;
		System.out.println(fee);
	}
}// end of Health class.