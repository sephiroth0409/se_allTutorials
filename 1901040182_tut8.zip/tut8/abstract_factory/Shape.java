package tutorial.tut7.todo.tut8.abstract_factory;

// Create the Shape interface
public interface Shape {
	void draw();
}
