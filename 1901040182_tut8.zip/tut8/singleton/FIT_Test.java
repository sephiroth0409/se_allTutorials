package tutorial.tut7.todo.tut8.singleton;

import java.util.Locale;

//Create the FIT_Test for testing purpose
public class FIT_Test {
	//TO-DO: Implement the main() method
	public static void main(String args[]) {
		//Create 2 new instances (objects) by calling getInstance() method
	FIT fit1= FIT.getInstance();
		//With 1st instance, display given text in upper case
 		String a = fit1.toLower();

		System.out.println(a);
		//With 2nd instance, display given text in lower case
	 
	}
}
