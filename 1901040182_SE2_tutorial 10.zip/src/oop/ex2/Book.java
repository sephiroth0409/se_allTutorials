package oop.ex2;

public class Book {
    private String title;
    private float price;
    private String author;

    public Book(String author, String title, float price) {
        this.setTitle(title);
        this.setAuthor(author);
        this.setPrice(price);
    }

    public String getTitle() throws IllegalArgumentException {
        if (title.length()<3){
            throw  new IllegalArgumentException("Title's not valid");
        }
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) throws IllegalArgumentException {
        if (price<=0)
        {
            throw new IllegalArgumentException("Price is not valid");
        }
        this.price = price;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) throws  IllegalArgumentException {
        String [] a = author.split(" ");
        if (!a[1].matches("[a-zA-Z_]+")){
            throw new IllegalArgumentException("Author name's not valid");
        }
        this.author = author;
    }

    @Override
    public String toString() {
        return "Book{" +
                "title='" + title + '\'' +
                ", price=" + price +
                ", author='" + author + '\'' +
                '}';
    }
}
