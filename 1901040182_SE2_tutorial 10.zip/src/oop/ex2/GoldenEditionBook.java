package oop.ex2;

public class GoldenEditionBook extends Book{
    public GoldenEditionBook(String author, String title, Float price) {
        super(author, title, price);
    }

    @Override
    public float getPrice() {
        return (float) (super.getPrice() + super.getPrice() * 0.3);
    }
}
