package oop.ex3;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter student info(first name last name falcuty number:  ");
        String a = sc.nextLine();
        String element[]= a.split(" ");
        Student new_stu = new Student(element[0], element[1], element[2]);
        System.out.println("First name: " + new_stu.getFirstname());
        System.out.println("last name: " + new_stu.getLastname());
        System.out.println("falcuty number: " + new_stu.getFalcuty_number());
        System.out.println("enter worker info (first name, last name, salary, working hours");
        String b = sc.nextLine();
        String element2[]=b.split(" ");

        Worker new_worker = new Worker(element2[0],element2[1],Double.parseDouble(element2[2]),Double.parseDouble(element2[3]));
        System.out.println("First name: " + new_worker.getFirstname());
        System.out.println("last name: " + new_worker.getLastname());
        System.out.println("week salary: " + new_worker.getWeek_salary());
        System.out.println("hours per day: "+new_worker.getHours_per_day());
        System.out.println("salary per day: "+ new_worker.CalcSalaryPerDay());
    }
}
