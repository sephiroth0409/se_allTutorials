package oop.ex3;

public class Worker extends Human{
    private double week_salary;
    private double hours_per_day;

    public double getWeek_salary() {
        return week_salary;
    }

    @Override
    public void setFirstname(String firstname) throws IllegalArgumentException {
        if(firstname.length()<3){throw new IllegalArgumentException("expected length more than 3 symbols! argument: firstName");}
        super.setFirstname(firstname);
    }

    @Override
    public void setLastname(String lastname) throws IllegalArgumentException {
        super.setLastname(lastname);
    }

    public void setWeek_salary(double week_salary) throws IllegalArgumentException {
        if(week_salary<10){throw new IllegalArgumentException("weeksalary must be >10");}
        this.week_salary = week_salary;
    }

    public double getHours_per_day() {
        return hours_per_day;
    }

    public void setHours_per_day(double hours_per_day) throws IllegalArgumentException{
        if(hours_per_day>12||hours_per_day<1){throw new IllegalArgumentException("Work hours must be between 1&12");}
        this.hours_per_day = hours_per_day;
    }

    public Worker(String firstname, String lastname, double week_salary, double hours_per_day) {
        super(firstname, lastname);
        setWeek_salary(week_salary);
        setHours_per_day(hours_per_day);
    }
    public double CalcSalaryPerDay(){
        return (this.week_salary/this.hours_per_day)/7;
    }
    public Worker(String firstname, String lastname) {
        super(firstname, lastname);
    }
}
