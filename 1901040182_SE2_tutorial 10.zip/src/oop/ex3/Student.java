package oop.ex3;

public class Student extends Human{
    private String falcuty_number;
    public Student(String firstname, String lastname) {
        super(firstname, lastname);
    }

    public Student(String firstname, String lastname, String falcuty_number) {
        super(firstname, lastname);
        setFalcuty_number(falcuty_number);
    }

    public String getFalcuty_number() {
        return falcuty_number;
    }


    public void setFalcuty_number(String falcuty_number) throws  IllegalArgumentException{
        if(falcuty_number.length()>10||falcuty_number.length()<5){throw new IllegalArgumentException("invalid falcuty number");}
        this.falcuty_number = falcuty_number;
    }

}
