package oop.ex3;

public class Human {
    private String firstname;
    private String lastname;

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) throws  IllegalArgumentException {
        if(!Character.isUpperCase(firstname.charAt(0)) || !(firstname.length()>=4)){throw new IllegalArgumentException("first name is not valid");}
        this.firstname=firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) throws  IllegalArgumentException{
        if(Character.isUpperCase(lastname.charAt(0)) && lastname.length()>3){this.lastname=lastname;}
        else{throw new IllegalArgumentException("last name is not valid");}
    }

    public Human(String firstname, String lastname) {
        setFirstname(firstname);
        setLastname(lastname);
    }

    @Override
    public String toString() {
        return "Human{" +
                "firstname='" + firstname + '\'' +
                ", lastname='" + lastname + '\'' +
                '}';
    }
}
