package oop.ex1;

public class Child extends Person{
    public Child(String name, int age) {
        super(name, age);
    }
    @Override
    public void setAge(int age) throws IllegalArgumentException {
        //validation
        //show error
        if (age>15){
            throw new IllegalArgumentException("Age must be lesser than 15");
        }
        //set value
        super.setAge(age);
    }
}
