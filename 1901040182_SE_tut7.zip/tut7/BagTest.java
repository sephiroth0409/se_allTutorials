package tutorial.tut7.todo.tut7;

public class BagTest {
    public static void main(String[]args){
        ArrayBag <String> bag1 = new ArrayBag<String>();
    bag1.add("hello");
    bag1.add("qwre");

        System.out.println(bag1.getCurrentSize());
    }


}
